// 混排样式验证：台词无人名前缀，仅颜色区分
const fs = require('fs');
const c = JSON.parse(fs.readFileSync('/workspace/fuderation-component-builder/component.json', 'utf8')).component;
let html = c.html;
const vals = {
  time: '第三日 18:47',
  location: '废墟教堂·地下',
  body: '第三天的黄昏来得比前两天更早，铅灰色的云层压在废墟上空，远处传来金属扭曲的呻吟。',
  dialogue: '莉娜:水……还有水吗……我真的快撑不住了。\n阿明:最后一瓶了，省着点喝。\n莉娜:那你还把饼干分给我一半？\n阿明:我小时候经历过更苦的日子，相信我，我们能撑到救援来。',
  thirst: '72',
  hunger: '58',
};
for (const [k, v] of Object.entries(vals)) html = html.split('$' + k + '$').join(v);
const page = `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>html,body{margin:0;padding:0;background:#4a4a4a}.wrap{width:360px;margin:0 auto;padding:20px 0}</style>
<style>${c.css}</style></head>
<body><div class="wrap">${html}</div><script>${c.script}<\/script></body></html>`;
fs.writeFileSync('/workspace/.sb-test/index.html', page);
console.log('written');
