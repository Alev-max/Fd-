// 从 component.json 生成测试页，模拟宿主替换占位符
const fs = require('fs');
const c = JSON.parse(fs.readFileSync('/workspace/fuderation-component-builder/component.json', 'utf8')).component;

let html = c.html;
const vals = {
  time: '第三日 14:32',
  location: '废墟教堂·地下',
  body: '昏暗的地下室里，水滴声一下一下敲在生锈的铁皮上。莉娜靠着斑驳的墙壁，数着最后半瓶水的刻度。',
  dialogue: '莉娜:水……还有水吗……\n阿明:最后一瓶了，省着点喝。\n莉娜:我们还能撑几天？\n阿明:撑到撑不住为止。',
  thirst: '65',
  hunger: '40',
};
for (const [k, v] of Object.entries(vals)) {
  html = html.split('$' + k + '$').join(v);
}

const page = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>html,body{margin:0;padding:0;background:#4a4a4a}
.wrap{width:360px;margin:0 auto;padding:20px 0}</style>
<style>${c.css}</style>
<style>.sb-bg{display:none}</style>
</head>
<body>
<div class="wrap">
${html}
</div>
<script>${c.script}<\/script>
</body>
</html>`;

fs.writeFileSync('/workspace/.sb-test/index.html', page);
console.log('written (img hidden), placeholders left:', (page.match(/\x24[a-z]+\x24/g) || []).length);
