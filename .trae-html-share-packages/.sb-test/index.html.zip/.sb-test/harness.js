// 名字标签效果验证
const fs = require('fs');
const c = JSON.parse(fs.readFileSync('/workspace/fuderation-component-builder/component.json', 'utf8')).component;
let html = c.html;
const vals = {
  time: '第三日 18:47',
  location: '废墟教堂·地下',
  body: '第三天的黄昏来得比前两天更早，铅灰色的云层压在废墟上空，远处传来金属扭曲的呻吟。莉娜蜷缩在教堂地下室的角落里，数着最后一瓶水的刻度线。',
  dialogue: '莉娜:水……还有水吗……我真的快撑不住了。\n莉娜:你看，我的手都在抖。\n阿明:最后一瓶了，省着点喝。我小时候经历过更苦的日子，那时候整整一个冬天我们全家就靠腌菜和雪水活下来的，相信我，我们能撑到救援来。\n阿明:先把饼干吃了。',
  thirst: '72',
  hunger: '58',
};
for (const [k, v] of Object.entries(vals)) html = html.split('$' + k + '$').join(v);
const page = `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>html,body{margin:0;padding:0;background:#4a4a4a}.wrap{width:360px;margin:0 auto;padding:20px 0}</style>
<style>${c.css}</style></head>
<body><div class="wrap">${html}</div><script>${c.script}<\/script></body></html>`;
fs.writeFileSync('/workspace/.sb-test/index.html', page);
console.log('written');
