// 超长内容分页测试：模拟宿主替换占位符
const fs = require('fs');
const c = JSON.parse(fs.readFileSync('/workspace/fuderation-component-builder/component.json', 'utf8')).component;

let html = c.html;
const longBody = [
  '第三天的黄昏来得比前两天更早，铅灰色的云层压在废墟上空，远处传来金属扭曲的呻吟。',
  '莉娜蜷缩在教堂地下室的角落里，数着最后一瓶水的刻度线，喉咙干得像塞满了砂纸。她已经开始出现幻觉——墙上浮现出妹妹的笑脸，一闪即逝。阿明在铁皮箱旁边清点物资：三罐过期的豆子、半包受潮的饼干、一把生锈的瑞士军刀。他把它在掌心掂了掂，塞回了靴筒里。',
  '头顶传来脚步声，碎石从裂缝里簌簌落下。两个人同时屏住呼吸。脚步声在头顶停留了很久，久到莉娜以为自己会先心跳过速而死，然后渐渐远去了。',
].join('\n\n');
const longDialogue = [
  '莉娜:水……还有水吗……我真的快撑不住了，喉咙里像有火在烧。',
  '阿明:最后一瓶了，省着点喝。我们现在最缺的不是水，是时间——救援队如果一周内不到，储备撑不过第八天。',
  '莉娜:那你还把饼干分给我一半？你自己昨天就没吃东西，我看见你把豆子罐头推给我的时候手都在抖。',
  '阿明:我块头大，消耗自然也大，这话反过来就是饿得也快，不过没关系，我小时候经历过更苦的日子，那时候整整一个冬天我们全家就靠腌菜和雪水活下来的。',
  '莉娜:别说了……我不想听你编故事哄我。',
  '阿明:不是编的。所以相信我，我们能撑到救援来。',
].join('\n');
const vals = {
  time: '第三日 18:47',
  location: '废墟教堂·地下',
  body: longBody,
  dialogue: longDialogue,
  thirst: '72',
  hunger: '58',
};
for (const [k, v] of Object.entries(vals)) {
  html = html.split('$' + k + '$').join(v);
}
const page = `<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>html,body{margin:0;padding:0;background:#4a4a4a}.wrap{width:360px;margin:0 auto;padding:20px 0}</style>
<style>${c.css}</style></head>
<body><div class="wrap">${html}</div><script>${c.script}<\/script></body></html>`;
fs.writeFileSync('/workspace/.sb-test/index.html', page);
console.log('written');
