# 本地组件预览

```bash
npm run preview          # http://localhost:5173
npm run preview -- --open --port 5199
```

端口被占用时会依次尝试后续端口（最多 100 个），终端和 `--open` 使用实际启动地址。
`--port 0` 可让系统分配空闲端口。

用**真实的 Fuderation 运行时**（冻结在 [`vendor/`](../../vendor/)）把 `src/` 渲染进模拟聊天气泡。
界面语言为中文，配色与排版直接取自站点自己的样式表。默认开启自动刷新，在最后一次修改后等待 400 ms 再更新。

`src/` 预览与 `npm run build` 复用同一组装函数：HTML / CSS / `script.js` 会先去注释，
iframe 模式的 `script.js` 还会按 `meta.json` 中的 `build` 设置缩短合适的局部变量名，
`script.ts` 继续编译并完整压缩。因此显示的字符数和渲染模式基于处理后的产物。
手动载入外部 `component.json` 时按文件内容预览，不额外进行构建清理。

Workshop 自带的预览把所有组件都塞进 iframe、不替换 `$参数$`、也跑不了宿主桥接。
这个工具三件事都做，所以它能提前暴露那些「只有真机试玩才会发现」的问题。

## 真实 vs. 模拟

| | 来源 |
|---|---|
| 消息解析、`$参数$` 替换、转义、代码块处理 | **官方运行时**，未改动 |
| DSL / iframe 模式判定 | **官方运行时** |
| DSL 模式下把 CSS 摊平成内联样式 | **官方运行时** |
| HTML 消毒（DSL 模式） | **官方运行时** + DOMPurify |
| iframe 文档、CSP、高度回报协议 | **官方运行时** |
| 注入的 `[组件使用说明]` 系统提示词 | **官方运行时** |
| 气泡与 Markdown 样式 | **官方样式表**，见 `vendor/site-chat.css` |
| Markdown 渲染 | markdown-it，配置与站点一致：`{html:true, linkify:true, breaks:true}` |
| 正文消毒（两道） | **官方配置**，见 `vendor/markdown-sanitize.json` |
| 挂载 iframe、响应高度回报 | 我们写的 —— 站点的挂载代码不在任何可达 chunk 里 |
| DSL 解释器与点击绑定 | 我们写的，同上（[`dsl.js`](dsl.js)） |
| 宿主：toast、fillInput、changeMsg、存储、世界书 | 我们写的模拟（[`host.js`](host.js)） |

标注为「我们写的」的部分是根据观测到的契约重建的，细节记录在
[`RUNTIME_INTERNALS.md`](../../.agents/skills/fuderation-component-builder/RUNTIME_INTERNALS.md)；
其余部分的行为与真实聊天完全一致。

## 面板说明

### 组件来源

默认预览 `src/`。也可以：

- 点「载入 component.json…」选择文件；
- 或**把 `component.json` 直接拖进窗口任意位置**。

导出信封（`{type, version, component:{…}}`）和裸的组件对象都能识别；如果只有单栏位
`source` 而没有 `html`，会按站点的规则拆出 HTML / CSS / Script。载入外部文件后可以随时
「回到 src/」。

- **重新加载组件**：重新读取 `src/`（外部 JSON 使用已载入的快照），恢复默认参数，清空消息正文、聊天输入框和调用记录。本地存储仍由「清除本地存储」单独管理。
- **自动刷新**：控制源码变更和参数／消息编辑的自动更新，连续编辑只在停下 400 ms 后刷新。关闭时取消待执行的自动刷新。
- **应用修改**：立即应用待处理的修改，保留当前参数和调用记录；关闭自动刷新后用它手动更新。组件自身的按钮、动画和宿主桥接仍照常运行。

### 参数

自动从 `html` / `css` / `script` 里扫出所有 `$参数$` 占位符，每个给一个输入框。
**改动即时重渲染** —— 不需要手写调用标签。转义过的 `\$名称\$` 会被正确忽略。

### 消息内容

组件在真实聊天里从来不是孤立出现的，所以这里可以填「组件前的正文」和「组件后的正文」，
两段都按 Markdown 渲染（站点用的就是 markdown-it，配置相同）。下面的「助手消息原文」
显示最终拼出来、运行时真正解析的那段文本。

勾选「直接编辑原文」可以完全手写消息 —— 适合测试同一条消息里调用两次组件、
把组件放进代码块、或者故意写错标签。

组件调用 `changeMsg()` 时会自动切到原文模式，因为那时候消息就是组件自己写的。

### 正文消毒提示

**气泡里显示的就是真实客户端会显示的内容——包括被删掉的部分。** 预览不会替你补回任何东西。

站点渲染聊天正文时跑两道，和组件的消毒规则完全不同：

1. `DOMPurify.sanitize(html, config)`，配置相当宽松——71 个标签（含 `form` / `button` /
   `input` / `svg`），并且用 `ADD_ATTR` **放行** `onclick` / `onerror` / `ontoggle`；
2. 一道正则，再把这些处理器剥掉，**除非**命中站点自己的 12 个回调
   （`window.copyCodeBlock(this)`、`this.classList.toggle('revealed')` 等），
   `onerror` 只在含 `this.onerror = null` 时保留，另外
   `onload` / `onmouseover` / `onsubmit` 等一律删除。

第二道正是第一道看起来那么松的原因：代码块的复制按钮
`<pre onclick="window.copyCodeBlock(this)">` 靠它活下来，而攻击者写的 `onclick` 活不下来。

两道规则都从线上 chunk 里抽出来存进 `vendor/markdown-sanitize.json` 并做了 SHA-256 固定，
所以这是**复现**而不是猜测。凡是被这条管线拿掉的东西，都会在气泡**下方**（而不是气泡里）
列出来——你看到的渲染结果和线上一致，同时知道路上少了什么。

### 聊天输入框

组件调用 `fillInput()` 时文本会写进这里，和真实客户端一样。它**不会发送任何东西** ——
只是让你确认组件塞给玩家的内容对不对。这是 `fillInput` 唯一的可见效果。

### 渲染模式 / 警告

当前落在哪种模式、为什么，以及会静默出问题的地方：CSS 被 1000 字符上限截断、
伪类不生效、DSL 脚本要点击才执行、iframe 里 `openUrl` 未定义、`ai_prompt` 为空等。

### 注入的系统提示词

故事线实际告诉模型的内容。`ai_prompt` 为空时这里什么都没有 —— 也就意味着 AI 永远不会调用它。

### 宿主调用记录

每一次到达宿主的桥接调用：toast、剪贴板、存储读写、世界书查询、消息改写。
「清除本地存储」会清掉预览用的 `localStorage` 命名空间。

## 它能提前发现什么

- **当前是哪种模式**，以及为什么。
- **CSS 被静默截断**，或 `:hover` / `@keyframes` 在 DSL 模式下根本不生效。
- **自动缩放**：切到 320px，看固定宽度的组件被整体缩小到看不清。
- **被消毒器删掉的标签** —— `canvas`、`form`、`header` 等。
- **`getMsgContent()` 在 iframe 里顶层调用返回空**。
- **`changeMsg` 来回切换**：自我重调用的组件真的能反复切换，因为消息框被真正改写并重新解析。

## 不改 `src/` 直接试一个组件

页面暴露了调试钩子：

```js
__preview.setComponent(
  { name: 'Demo', html: '<div>$T$</div>', css: '.x{}', script: '' },
  '<$Demo$><T>你好</T></$Demo$>',
);
```

## 刷新被冻结的运行时

```bash
npm run vendor:runtime              # 校验已提交的副本
npm run vendor:runtime -- --update  # 从线上重新拉取（含样式表子集）
```

详见 [`vendor/README.md`](../../vendor/README.md)，其中包含许可证说明 —— fork 本仓库前请先阅读。

## 技能内置自检组件

运行 `npm run build:diagnostics`，再载入
`.agents/skills/fuderation-component-builder/assets/diagnostics/` 下 `dsl`、
`dsl-storage`、`dsl-style`、`dsl-guard`、`iframe`、`iframe-data` 目录中生成的 `component.json`。它们分别提供 DSL 桥接断言、
故意触发拒绝的 DSL 控制组，以及自动运行的 iframe 功能检查和独立的视觉勾选表。

`npm run test:diagnostics` 运行 DOM 功能测试，并故意破坏部分操作验证自检能够报错。
这些测试不等于浏览器视觉检查；DSL 执行仍使用预览工具的重建解释器。
完整步骤与验证范围见 [DIAGNOSTICS.md](../../.agents/skills/fuderation-component-builder/DIAGNOSTICS.md)。

预览现在先模拟 Workshop 对 HTML/CSS/脚本的导入去注释，再交给运行时渲染。
DSL 执行最多 12 条语句（模式校验的 32 条不是执行预算）；超过时会显示警告。
