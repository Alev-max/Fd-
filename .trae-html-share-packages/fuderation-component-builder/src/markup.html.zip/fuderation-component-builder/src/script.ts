// StoryBox — 生存剧情对话框
// AI 参数经 HTML 转义后写入 #sbData 隐藏区，脚本从 DOM 读取（推特组件同款模式）。
// 重要：整个脚本（含编译产物）不允许出现字面量美元符——宿主的占位符替换机制
// 会把任意成对美元符之间的内容当作未知参数整体吞掉（Alev 组件嵌套教程的已知坑）。
// 因此：正则一律不用美元符行尾锚点；trim / 垃圾行检测用字符循环；
// 占位符检测用 charCode 36 数值比较（esbuild 无法折叠，不会还原出字面量）。

interface Line {
  name: string;
  text: string;
  narr: boolean;
}

const PALETTE = ['#ffd166', '#7ec8ff', '#ff9eae', '#8af0b4', '#d2a8ff', '#ffb37a', '#8ff0e0', '#f7ee8c'];
const PER_PAGE = 4;
const NARRS = new Set(['旁白', 'narrator', 'narration', '内心', '独白', '系统']);
const LINE_RE = /^([^:：。，！？!?]{1,16}?)\s*[:：]\s*([\s\S]+)/;
const LEAN = ' \t\n\r*_[（【(';
const TRAIL = ' \t\n\r*_）]】)';
const JUNK = '-—─=·•.。 \t';

function byId(id: string): HTMLElement {
  return document.getElementById(id) as HTMLElement;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// 检测残留的未替换占位符（占位符两侧的定界符 charCode 为 36）
function hasDollar(s: string): boolean {
  for (let i = 0; i < s.length; i++) {
    if (s.charCodeAt(i) === 36) return true;
  }
  return false;
}

function isPh(s: string): boolean {
  return !s || !s.trim() || hasDollar(s);
}

function readData(id: string): string {
  const el = byId(id);
  const t = el ? el.textContent || '' : '';
  return isPh(t) ? '' : t;
}

// 去掉 AI 可能带上的 markdown 强调符号与包裹符号（不剥离破折号，中文常用）
function tidy(s: string): string {
  let a = 0;
  let b = s.length;
  while (a < b && LEAN.indexOf(s.charAt(a)) >= 0) a++;
  while (b > a && TRAIL.indexOf(s.charAt(b - 1)) >= 0) b--;
  return s.slice(a, b);
}

// 整行只由分隔符构成（如 --- 、——— 、···）视为垃圾行
function isJunk(s: string): boolean {
  if (!s) return true;
  for (let i = 0; i < s.length; i++) {
    if (JUNK.indexOf(s.charAt(i)) < 0) return false;
  }
  return true;
}

function isNarrName(name: string): boolean {
  return !name || NARRS.has(name) || NARRS.has(name.toLowerCase());
}

// 解析正文段落：空行分段，垃圾行丢弃（正文每段作为一条叙述，排在对话之前）
function parseBody(raw: string): Line[] {
  const paras = raw
    .split(/\r?\n\s*\r?\n/)
    .map((s) => s.trim())
    .filter((s) => s && !isJunk(s));
  const out: Line[] = [];
  for (const p of paras) {
    const text = tidy(p.replace(/\r?\n/g, ' '));
    if (text) out.push({ name: '', text, narr: true });
  }
  return out;
}

// 解析对话：过滤空行、纯分隔行、空台词 —— 保证绝不产生空白占位页
function parseLines(raw: string): Line[] {
  let parts = raw
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter((s) => s && !isJunk(s));
  // 模型把换行折叠成 "|" 分隔时兜底（Alev 的 Dice options 同款分隔符）
  if (parts.length === 1 && parts[0].indexOf('|') >= 0) {
    parts = parts[0]
      .split('|')
      .map((s) => s.trim())
      .filter((s) => s && !isJunk(s));
  }
  const out: Line[] = [];
  for (const p of parts) {
    const m = p.match(LINE_RE);
    if (m) {
      const name = tidy(m[1]);
      const text = tidy(m[2]);
      if (!text) continue; // 空台词直接丢弃
      out.push({ name, text, narr: isNarrName(name) });
    } else {
      const last = p.charAt(p.length - 1);
      if (last === ':' || last === '：') continue; // 只有名字没有台词，丢弃
      const text = tidy(p);
      if (text) out.push({ name: '', text, narr: true });
    }
  }
  return out;
}

const lines: Line[] = [];
const colors = new Map<string, string>();
let page = 0;
let forward = true;

function pageCount(): number {
  return Math.max(1, Math.ceil(lines.length / PER_PAGE));
}

function render(): void {
  const stage = byId('sbStage');
  const start = page * PER_PAGE;
  const slice = lines.slice(start, start + PER_PAGE);
  stage.className = 'sb-stage' + (forward ? '' : ' sb-back');
  stage.innerHTML = slice
    .map((l) => {
      if (l.narr) {
        return '<div class="sb-line sb-narr"><div class="sb-text">' + esc(l.text) + '</div></div>';
      }
      const c = colors.get(l.name) || '#ffd166';
      return (
        '<div class="sb-line sb-talk" style="--sc:' + c + '">' +
        '<span class="sb-name">' + esc(l.name) + '：</span>' +
        '<span class="sb-text">' + esc(l.text) + '</span></div>'
      );
    })
    .join('');
  byId('sbPageCur').textContent = String(page + 1);
  byId('sbPageMax').textContent = String(pageCount());
  const prev = byId('sbPrev') as HTMLButtonElement;
  const next = byId('sbNext') as HTMLButtonElement;
  prev.disabled = page <= 0;
  next.disabled = page >= pageCount() - 1;
}

function setStat(fillId: string, numId: string, raw: string): void {
  let v = parseInt(String(raw).replace(/[^\d]/g, ''), 10);
  if (isNaN(v)) v = 0;
  v = Math.max(0, Math.min(100, v));
  const fill = byId(fillId);
  fill.style.width = v + '%';
  fill.className = 'sb-fill' + (v >= 70 ? ' sb-danger' : v >= 40 ? ' sb-warn' : ' sb-ok');
  byId(numId).textContent = String(v);
}

(function init(): void {
  const t = readData('sbTime');
  const loc = readData('sbLoc');
  byId('sbTimeOut').textContent = t || '——';
  byId('sbLocOut').textContent = loc || '未知区域';

  const parsed = parseBody(readData('sbBody')).concat(parseLines(readData('sbDialogue')));
  if (parsed.length === 0) {
    parsed.push({ name: '', text: '（四周一片死寂，什么也没有发生。）', narr: true });
  }
  let ci = 0;
  for (const l of parsed) {
    lines.push(l);
    if (!l.narr && !colors.has(l.name)) colors.set(l.name, PALETTE[ci++ % PALETTE.length]);
  }

  page = 0;
  forward = true;
  if (pageCount() <= 1) byId('sbPager').style.display = 'none';
  render();

  (byId('sbPrev') as HTMLButtonElement).onclick = function (e: MouseEvent): void {
    e.stopPropagation();
    if (page > 0) {
      forward = false;
      page--;
      render();
    }
  };
  (byId('sbNext') as HTMLButtonElement).onclick = function (e: MouseEvent): void {
    e.stopPropagation();
    if (page < pageCount() - 1) {
      forward = true;
      page++;
      render();
    }
  };

  setStat('sbThirstFill', 'sbThirstNum', readData('sbThirst'));
  setStat('sbHungerFill', 'sbHungerNum', readData('sbHunger'));
})();
